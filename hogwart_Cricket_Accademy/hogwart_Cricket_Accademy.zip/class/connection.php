<?php


$host = 'localhost';
$user = 'id1086219_ab';
$password = '123456';
$database = 'id1086219_ab';
$con = mysqli_connect($host, $user, $password);
mysqli_select_db($con, "u443636314_ab");
?>